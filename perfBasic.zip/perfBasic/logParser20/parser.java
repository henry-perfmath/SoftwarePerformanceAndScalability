package logParser20;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.*;
import java.util.*;
import java.util.HashMap;
import java.util.Stack;
import org.w3c.dom.Document;

public class parser {
    private PrintWriter dotWriter;

    private PrintWriter xmlWriter;

    private Stack callStack;

    public HashMap relations;

    public BufferedReader dataReader;

    public PrintWriter dataWriter;

    public parser() {
        callStack = new Stack();
        relations = new HashMap();
        createReaderAndWriters();
    }

    public boolean isCallEnd(String line) {
        boolean isCallEnd = false;
        for (int i = 0; i < params.callEndIdentifiers.length; i++) {
            if (line.contains(params.callEndIdentifiers[i])) {
                isCallEnd = true;
                continue;
            }
        }
        return isCallEnd;
    }

    public boolean isSelfNode(String line) {
        boolean isSelfNode = false;
        for (int i = 0; i < params.selfNodeIdentifiers.length; i++) {
            if (line.contains(params.selfNodeIdentifiers[i])) {
                isSelfNode = true;
                continue;
            }
        }
        return isSelfNode;
    }

    public String processNodeName(String name) {
        String nodeName = new String(name);
        while (nodeName.contains(".")) {
            nodeName = nodeName.replace('.', '_');
        }
        while (nodeName.contains("-")) {
            nodeName = nodeName.replace('-', '_');
        }
        while (nodeName.contains(">")) {
            nodeName = nodeName.replace('>', '_');
        }
        while (nodeName.contains(":")) {
            nodeName = nodeName.replace(':', '_');
        }
        return nodeName;
    }

    public long getNodeTime(String lineThread) {
        String nodeTime = lineThread.substring(0, lineThread
                        .indexOf("|^"));
        return Long.parseLong(nodeTime);
    }

    public String getNodeType(String lineThread) {
        int beginIndex = lineThread.indexOf("|~") + 2;
        int endIndex = lineThread.indexOf("$$");
        String nodeType = lineThread.substring(beginIndex, endIndex);
        return nodeType;
    }

    public String getText(String lineThread) {
        String text = lineThread.substring(
            lineThread.indexOf("|^") + 2, lineThread.indexOf(("|~")));

        return text.trim();
    }

    public String getNodeName(String lineThread) {
        String nodeName = "";
        int startIndex = lineThread.lastIndexOf("|^") + 2;
        if (startIndex < 0)
            startIndex = 0;
        int endIndex = lineThread.indexOf("|~");
        nodeName = lineThread.substring(startIndex, endIndex).trim();

        if (lineThread.contains("API")) {
            endIndex = lineThread.indexOf(" ", startIndex);
            if (endIndex < 0)
                endIndex = lineThread.indexOf("|~");
            nodeName = lineThread.substring(startIndex + 1, endIndex);
        } else if (nodeName.startsWith("+")) {
            nodeName = getNodeType(lineThread)
                + nodeName.substring(1, nodeName.indexOf(" "));
        } else {
            nodeName = getNodeType(lineThread)
                + nodeName.substring(0, nodeName.indexOf(" "));
        }
        nodeName = processNodeName(nodeName);
        return nodeName;
    }

    public void printRootToThreadLink(int index) {
        long TnPortion = logReader.threadTimeDelta[index] * 100
            / logReader.allThreadTimeTotal;
        String nodeLabel = "T" + index;
        String relationLabel = "";
        if (params.graphByThread) {
            relationLabel = "[color=orange, style=bold,label=\"T"
                + index + "\\n(" + logReader.threadTimeDelta[index]
                + ", " + TnPortion + "%)\"];";
        } else {
            relationLabel = "[color=orange, style=bold,label=\"T"
                + index + "\\n" + logReader.threadTimeDelta[index]
                + "\\n\\n" + "\\n" + TnPortion + "%\\n\\n " + "\\n"
                + "\"];";
        }

        if (!params.graphByThread) {
            nodeLabel = "T";
        }
        dotWriter.println("root->" + nodeLabel + relationLabel);
    }

    public void printThreadNodes(int index) {
        long TnPortion = logReader.threadTimeDelta[index] * 100
            / logReader.allThreadTimeTotal;
        // utility.display("T" + index + ": " + TnPortion + "%");
        String nodeLabel = "T" + index;

        if (!params.graphByThread) {
            nodeLabel = "T";
        } else {
            if (TnPortion > params.threadPercentTimeFilter) {
                dotWriter.println(nodeLabel
                    + "[color=red,style=bold,label=\"" + nodeLabel
                    + "\\n(" + logReader.threadTimeDelta[index]
                    + ", " + TnPortion + "%)\"];");
            } else {
                dotWriter.println(nodeLabel
                    + "[color=blue,style=solid,label=\"" + nodeLabel
                    + "\\n(" + logReader.threadTimeDelta[index]
                    + ", " + TnPortion + "%)\"];");
            }
        }
    }

    public boolean execludeThisThread(int index) {
        long threadPercentTime = 0;
        boolean skip = false;
        threadPercentTime = logReader.threadTimeDelta[index] * 100
            / logReader.allThreadTimeTotal;
        if (threadPercentTime < params.threadPercentTimeFilter) {
            skip = true;
        }
        return skip;
    }

    public void checkTraceTreeWalkThrough(String s) {
        if (params.traceTreeWalkThrough) {
            utility.display("treeDepth = " + s);
        }
    }

    public void processRelation(int index, Link link) {
        long[] relationInfo = new long[3];
        String fromId = link.getSourceNode().getId();
        String toId = link.getDestNode().getId();
        String relationId = fromId + "->" + toId;
        long elapsedTime = link.getElapsedime();
        long lastCallEndTime = link.getDestNode().getCallEndTime();
        if (relations.containsKey(relationId)) {
            long[] temp = (long[]) relations.get(relationId);
            relationInfo[0] = temp[0] + 1;
            relationInfo[1] = temp[1] + elapsedTime;
            relationInfo[2] = lastCallEndTime; // temp [2] +
            // lastCallEndTime;
        } else {
            relationInfo[0] = 1;
            relationInfo[1] = elapsedTime;
            relationInfo[2] = lastCallEndTime;
        }
        link.setCallCount((int) relationInfo[0]);
        link.setElapsedTime(relationInfo[1]);
        relations.put(relationId, relationInfo);
    }

    public int[] getRelationInfo(String relationId, HashMap relations) {
        int[] countAndETime = new int[2];
        countAndETime[0] = -1;
        countAndETime[1] = -1;
        if (relations.containsKey(relationId)) {
            int[] temp = (int[]) relations.get(relationId);
            countAndETime[0] = temp[0];
            countAndETime[1] = temp[1];

        }
        return countAndETime;
    }

    public BufferedReader[] createThreadReader() {
        BufferedReader[] threadReader = new BufferedReader[params.maxThreads];
        for (int i = 0; i < logReader.threadIndexMax; i++) {
            threadReader[i] = utility
                            .createReader(logReader.threadFileNames[i]);
        }
        return threadReader;
    }

    public void createReaderAndWriters() {
        String dotFileName = params.callTreeDotFile;
        dotWriter = utility.createWriter(dotFileName);
        String xmlFileName = params.callTreeXMLFile0;
        utility.display("initial xml file: " + xmlFileName);
        xmlWriter = utility.createWriter(xmlFileName);

        String dataFileName = params.outputFileDir + "/"
            + params.fileNamePrefix + "_data.txt";
        dataWriter = utility.createWriter(dataFileName);
        dataReader = utility.createReader(dataFileName);
    }

    public Node makeNode(String namespace, int index,
                    String lineThread) {
        String nodeName = getNodeName(lineThread);
        long nodeCallStartTime = getNodeTime(lineThread);
        String nodeType = getNodeType(lineThread);
        long nodeCallEndTime = -1;
        String text = getText(lineThread).trim();
        Node currentNode = new Node(namespace, nodeName,
                        nodeCallStartTime, nodeCallEndTime, nodeType,
                        0, 0, text);

        return currentNode;
    }

    public void writeXmlHeaders() {
        xmlWriter
                        .println("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
        xmlWriter.println("<diagram>");
    }

    public void processLogByThread() {

        long startTime = System.currentTimeMillis();
        utility.display("start parsing logs ... ");
        threadLoop();
        long endTime = System.currentTimeMillis();
        utility.display("process threads: " + (endTime - startTime)
            + " ms");
        System.out.println("Start xml processing ...");
        if (params.xmlProcessing) {
            xmlProcessing();
            utility.display("xml processing: "
                + (System.currentTimeMillis() - endTime) + " ms");
        }
        analyzer.processData(dataReader);
    }

    public void xmlProcessing() {
        String xmlFileName = params.callTreeXMLFile0;
        xmlProcessor xp = new xmlProcessor(xmlFileName);

        utility
                        .println(params.sumWriter,
                            "updateAllLinks ... ", true);
        xp.updateAllLinks(relations);
        utility.println(params.sumWriter, "updateAllDestNodes ... ",
            true);
        Document doc = xp.updateAllDestNodes(relations);
        utility.println(params.sumWriter, "applying filter ... ",
            true);
        Document docFinal = xp.treeFilter(doc);
        utility.println(params.sumWriter,
            "serializing xml file ... ", true);
        xp.writeDocumentToFile(docFinal);
    }

    public Node processRootNode(HashSet callPath) {
        long rootStartTime = logReader.traceLogOnDateInMS;
        long rootEndTime = logReader.allThreadTimeMax;
        if (params.relativeToLogOnTime) {
            rootStartTime = 0;
        }
        Node root = new Node("ROOT", "ROOT", rootStartTime,
                        rootEndTime, "ROOT",
                        (int) logReader.allThreadTimeTotal, 0, "ROOT");
        callStack.push(root);
        logWriter.logWriteNode(xmlWriter, root);
        callPath.add(new String(root.getId()));
        return root;
    }

    public Node processThreadNode(int index, Node root,
                    HashSet callPath) {
        Node threadNode = new Node("ROOT", "T" + index,
                        logReader.threadTimeMin[index],
                        logReader.threadTimeMax[index], "Thread",
                        (int) logReader.threadTimeDelta[index], 0,
                        "T" + index);
        callStack.push((Node) threadNode);
        callPath.add(new String(threadNode.getId()));
        Link link = new Link("", "ROOT_T" + index, root, threadNode,
                        1, logReader.threadTimeDelta[index], "true",
                        "green");
        processRelation(index, link);

        logWriter.logWriteNode(xmlWriter, threadNode);

        checkTraceTreeWalkThrough(callStack.size()
            + " at begining of T" + index);
        return threadNode;
    }

    public int threadLoop() {
        HashSet callPath = new HashSet();
        String lineThread = "";
        BufferedReader[] threadReader = createThreadReader();
        writeXmlHeaders();

        // Node root = processRootNode(callTree);
        Node root = processRootNode(callPath);
        // for (int index = 0; index < 9; index++) {
        for (int index = 0; index < logReader.threadIndexMax; index += params.threadSample) {
            //if (index < 21) continue;
            if (execludeThisThread(index))
                continue;
            params.sumWriter.println("processing thread " + index
                + " callStack has " + callStack.size() + " items"
                + " callTree has " + callPath.size() + " items");
            utility.display("processing thread " + index
                + " callStack has " + callStack.size() + " items"
                + " callTree has " + callPath.size() + " items");
            callPath.clear();
            processThreadNode(index, root, callPath);
            try {
                while ((lineThread = threadReader[index].readLine()) != null) {
                    if (isCallEnd(lineThread)) {
                        processCallEnd(index, lineThread, callPath);
                    } else { // nonCallEnd
                        processCallStart(index, lineThread, callPath);
                        if (isSelfNode(lineThread)) {
                            processCallEnd(index, lineThread,
                                callPath);
                        } // end selfNodeCheck
                    }
                }
            } catch (IOException e) {
                utility.display("error reading "
                    + logReader.threadFileNames[index]);
            }
            logWriter.writeEndNode(xmlWriter);
            checkTraceTreeWalkThrough("treeDepth = "
                + callStack.size() + " at end of thread " + index);
            // process remaining items in stack
            postCheckCallStack(index);
            printProcessByThread(index, callStack.size());
        } // end for
        callPath.clear();
        logWriter.writeEndNode(xmlWriter); // conclude root node
        //xmlWriter.println("</treenode>");
        xmlWriter.println("</diagram>");
        writeDotHeaders();
        writeRelationsInDotFormat();
        dotWriter.println("}");
        // if (logReader.threadIndexMax > 2) System.exit(-1);
        closeAllWriters();

        if (params.deleteThreadFiles)
            deleteThreadFiles(threadReader);

        return callStack.size();
    }

    public void closeAllWriters() {
        xmlWriter.close();
        dataWriter.close();
        dotWriter.close();
    }

    public Node processCallStart(int index, String lineThread,
                    HashSet callPath) {

        String namespace = utility.getNamespace(callStack);
        // System.out.println("namespace = " + namespace);
        Node currentNode = makeNode(namespace, index, lineThread);
        checkTraceTreeWalkThrough("processCallStart 0: namespace = "
            + currentNode.getNamespace() + " nodeName = "
            + currentNode.getName());
        callStack.push((Node) currentNode);
        String nodeId = currentNode.getId();
        if (!callPath.contains(nodeId)) {
            callPath.add(nodeId);
            logWriter.logWriteNode(xmlWriter, currentNode);
        }
        return currentNode;
    }

    public Link processCallEnd(int index, String lineThread,
                    HashSet callPath) {
        checkTraceTreeWalkThrough(callStack.size()
            + " at beginning of callEnd: "
            + ((Node) callStack.peek()).getId());
        String namespace = utility.getNamespace(callStack);
        Link link = processCallEnd(namespace, index, lineThread);
        String linkId = link.getId();
        if (!callPath.contains(linkId)) {
            callPath.add(linkId);
            logWriter.writeLink(xmlWriter, link);
            logWriter.writeEndNode(xmlWriter);
        }
        processRelation(index, link);
        checkTraceTreeWalkThrough(callStack.size()
            + " at end of callEnd: "
            + ((Node) callStack.peek()).getId());
        return link;
    }

    public Link processCallEnd(String namespace, int index,
                    String line) {
        long calleeEndTime = getNodeTime(line);

        Node callee = (Node) callStack.pop();
        callee.setCallEndTime(calleeEndTime);
        callee.setType("test");

        long calleeStartTime = callee.getCallStartTime();
        long elapsedTime = calleeEndTime - calleeStartTime;
        /*
         * if (callee.getName().equals(caller.getName())) {
         * utility.display("Recursive: " + callStack.size() + " " +
         * namespace + " " + caller.getName() + " " + callee.getName() + " " +
         * callee.getTimeSum() + " " + elapsedTime); }
         */
        callee.setElapsedTimeSum(callee.getElapsedTimeSum()
            + (int) elapsedTime);
        Node caller = (Node) callStack.peek();
        String linkName = caller.getName() + "__" + callee.getName();
        Link link = new Link(namespace, linkName, caller, callee, 1,
                        elapsedTime, "true", "green");
        String text = callee.getText();
        if (elapsedTime > 0) { // avoid big data file
            dataWriter.println(elapsedTime + "~ " + index + "~ "
                + text);
        }
        return link;
    }

    public void postCheckCallStack(int index) {
        int stackSize = callStack.size();
        for (int i = 0; i < stackSize - 1; i++) {
            Node target = (Node) callStack.pop();
            Node source = (Node) callStack.peek();
            target.setCallEndTime(logReader.threadTimeMax[index]);
            long eTime = logReader.threadTimeMax[index]
                - logReader.threadTimeMin[index];
            Link link = new Link("", "ROOT_T" + index, source,
                            target, 1, eTime, "true", "green"); //
            logWriter.writeLink(xmlWriter, link);
        }
    }

    public int getThreadIndexFromTargetId(String toId) {
        int threadIndex = 0;
        if (toId.startsWith("ROOT:T")) {
            threadIndex = Integer.parseInt(toId.substring(6, toId
                            .length()));
        } else if (toId.startsWith("ROOT.T")) {
            int colonIndex = toId.indexOf(":", 5);
            int commaIndex = toId.indexOf(".", 5);
            if (commaIndex < 0) {
                threadIndex = Integer.parseInt(toId.substring(6,
                    colonIndex));
            } else {
                threadIndex = Integer.parseInt(toId.substring(6,
                    commaIndex));
            }
        }
        return threadIndex;
    }

    public String getDotFromId(String fromId) {

        String IdReplace = fromId;
        do {
            IdReplace = IdReplace.replace(":", "_");
        } while (IdReplace.contains(":"));
        do {
            IdReplace = IdReplace.replace(".", "_");
        } while (IdReplace.contains("."));

        return IdReplace;
    }

    public String getDotToId(String toId) {

        String IdReplace = toId;
        do {
            IdReplace = IdReplace.replace(":", "_");
        } while (IdReplace.contains(":"));
        do {
            IdReplace = IdReplace.replace(".", "_");
        } while (IdReplace.contains("."));

        return IdReplace;
    }

    public String getDotFromName(String fromId) {
        String dotFromName = fromId
                        .substring(fromId.indexOf(":") + 1);
        do {
            dotFromName = dotFromName.replace(".", "_");
        } while (dotFromName.contains("."));
        return dotFromName;
    }

    public String getDotToName(String toId) {
        String dotToName = toId.substring(toId.indexOf(":") + 1);
        do {
            dotToName = dotToName.replace(".", "_");
        } while (dotToName.contains("."));
        return dotToName;
    }

    public void writeRelationsInDotFormat() {

        Set entries = relations.entrySet();
        Iterator it = entries.iterator();
        ArrayList toIdArray = new ArrayList();
        int nodeIndex = -1;
        while (it.hasNext()) {
            Map.Entry entry = (Map.Entry) it.next();
            String id = entry.getKey().toString();
            // utility.display("WRITEDOT: id = " + id);

            String fromId = id.substring(0, id.indexOf("-"));
            String dotFromId = getDotFromId(fromId);
            String dotFromName = getDotFromName(fromId);

            String toId = id.substring(id.indexOf(">") + 1, id
                            .length());
            String dotToName = getDotToName(toId);
            String dotToId = getDotToId(toId);
            // System.out.println("DOT: fromId = " + fromId + " toId =
            // " + toId);
            int threadIndex = getThreadIndexFromTargetId(toId);
            String relationId = dotFromId + "->" + dotToId;

            long[] temp = (long[]) (entry.getValue());
            if (temp[1] >= params.elapsedTimeThresholdInMS) {
                nodeIndex++;
                toIdArray.add(nodeIndex, dotToName + ":" + dotToId);
                if (params.graphByThread) {
                    logWriter.writeDotRelation(dotWriter, dotFromId,
                        dotFromName, relationId, dotToId, dotToName,
                        threadIndex, (int) temp[0], (int) temp[1]);
                } else {
                    utility.display("fromId = " + fromId + " toId = "
                        + toId);
                    if (isThreadNode(fromId)) {
                        dotFromName = "T";
                    }
                    if (isThreadNode(toId)) {
                        dotToName = "T";
                    }
                    logWriter.writeDotRelation(dotWriter,
                        dotFromName, dotFromName, dotFromName + "->"
                            + dotToName, dotToName, dotToName,
                        threadIndex, (int) temp[0], (int) temp[1]);
                }
            }
        }
        // create subgraph
        if (params.graphByThread && params.subGraph) {
            createDotSubGraph(toIdArray);
        }
    }

    public void printProcessByThread(int relationIndex, int treeDepth) {
        if (treeDepth == 1) {
            utility.display("   treeDepth = " + treeDepth
                + " at end -> call graph traversing ok");
        } else {
            utility.display("   treeDepth = " + treeDepth
                + " at end -> call graph traversing wrong");
        }
        utility.display("   # of relations = " + relationIndex);
    }

    public boolean hasThreadNode(String nodeId) {
        boolean hasThreadNode = false;
        int index = nodeId.indexOf(":ROOT_T");
        if (index < 0)
            return false;
        // utility.display (nodeId.substring(0, index) + " " +
        // nodeId.substring (index + 6));
        if (nodeId.substring(0, index).equals(
            nodeId.substring(index + 6))) {
            hasThreadNode = true;
        }
        return hasThreadNode;
    }

    public boolean isThreadNode(String nodeId) {
        boolean isThreadNode = false;
        if (nodeId.startsWith("ROOT:T"))
            return true;
        return isThreadNode;
    }

    public void deleteThreadFiles(BufferedReader[] threadReader) {
        // delete thread files
        for (int i = 0; i < logReader.threadIndexMax; i++) {
            try {
                threadReader[i].close();
            } catch (IOException ie) {
            }
            // utility.display(System.getProperty("user.dir")+ "\\" +
            // threadFileNames [i]);
            File file = new File(System.getProperty("user.dir")
                + "\\" + logReader.threadFileNames[i]);
            if (!file.delete()) {
                utility.display("Cannot delete "
                    + logReader.threadFileNames[i]);
            }
        }
    }

    public void writeDotHeaders() {
        dotWriter.println("digraph G {");
        // dotWriter.println("rankdir=LR;");
        //dotWriter.println("node[shape=\"box\",style=\"filled\""
        //    + ",color=\"lightgoldenrod\"];");
        dotWriter.println("node[shape=\"box\"];");
    }

    public void createDotSubGraph(ArrayList nodeList) {

        String[] destNodes = new String[nodeList.size()];
        nodeList.toArray(destNodes);
        Arrays.sort(destNodes);
        dotWriter
                        .println("subgraph \"cluster_T"
                            + "\"{ label=\"T\";");
        for (int i = 0; i < nodeList.size(); i++) {
            if (hasThreadNode(destNodes[i])) {
                dotWriter.println("ROOT_"
                    + destNodes[i].substring(0, destNodes[i]
                                    .indexOf(":")) + ";");
            }
        }
        dotWriter.println("}");
        String previousNodeId = destNodes[0];
        String currentNodeId = destNodes[1];
        int indexCurrentNode = currentNodeId.indexOf(":");
        int indexPreviousNode = previousNodeId.indexOf(":");

        dotWriter.println("subgraph \"cluster_"
            + previousNodeId.substring(0, indexPreviousNode)
            + "\"{ label=\""
            + previousNodeId.substring(0, indexPreviousNode) + "\";"
            + previousNodeId.substring(indexPreviousNode + 1) + ";");

        for (int i = 2; i < nodeList.size(); i++) {
            previousNodeId = destNodes[i - 1];
            currentNodeId = destNodes[i];

            if (!hasThreadNode(currentNodeId)) {
                indexCurrentNode = currentNodeId.indexOf(":");
                indexPreviousNode = previousNodeId.indexOf(":");
                if (!previousNodeId.substring(0, indexPreviousNode)
                                .equals(
                                    currentNodeId.substring(0,
                                        indexCurrentNode))) {
                    // new cluster
                    dotWriter.println("}");
                    dotWriter
                                    .println("subgraph \"cluster_"
                                        + currentNodeId.substring(0,
                                            indexCurrentNode)
                                        + "\"{ label=\""
                                        + currentNodeId.substring(0,
                                            indexCurrentNode)
                                        + "\";"
                                        + currentNodeId
                                                        .substring(indexCurrentNode + 1)
                                        + ";");
                } else {
                    dotWriter.println(currentNodeId
                                    .substring(indexCurrentNode + 1)
                        + ";");
                }
            }
        }
        dotWriter.println("}");

    }
}
