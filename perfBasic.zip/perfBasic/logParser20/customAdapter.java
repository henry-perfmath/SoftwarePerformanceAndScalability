package logParser20;
//implement your custom adapter here
public class customAdapter {

	public static void convertLogFile(String inputFileName, String apfInputFileName, 
            String[] ignoreLinesIdentifiers) {

	}
}
