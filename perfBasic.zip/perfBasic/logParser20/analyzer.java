package logParser20;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.*;
import java.util.HashMap;

public class analyzer {
    private static PrintWriter callCostWriter;

    public analyzer() {
    }
    public static void createCallCostWriter () {
        String callCostFileName = params.outputFileDir + "/"
            + params.fileNamePrefix + "_callCost.txt";
        callCostWriter = utility.createWriter(callCostFileName);
    }
    public static void processData(BufferedReader dataReader) {
        createCallCostWriter ();
        ArrayList callRecords = new ArrayList();
        String dataLine = "";
        int lineCount = -1;
        do {
            try {
                dataLine = dataReader.readLine();
                if (dataLine != null) {
                    lineCount++;
                    callRecords.add(lineCount, dataLine);
                }
            } catch (IOException ioe) {

            }
        } while (dataLine != null);
        utility.display("sortDataByThread ... " + callRecords.size()
                        + " calls");
        sortDataByThread(callRecords);
        callRecords.clear();
    }

    public static void sortDataByThread(ArrayList callRecords) {
        String[] records = new String[callRecords.size()];
        callRecords.toArray(records);
        // Arrays.sort(records);
        String identifier = "";
        HashMap calls = new HashMap();
        String[] call = new String[5];
        for (int i = 0; i < callRecords.size(); i++) {
            // String dataLine = (String)callRecords.get(i);
            String dataLine = records[i];
            // utility.display("dataLine = " + dataLine);
            StringTokenizer st = new StringTokenizer(dataLine, "~");
            for (int j = 0; j < 3; j++) {
                call[j] = st.nextToken().toString().trim();
            }
            CallRecord callRecord = new CallRecord(Integer
                            .parseInt(call[0]), Integer
                            .parseInt(call[1]), 1, call[2]);
            identifier = Integer.toString(callRecord.getText()
                            .hashCode());
            Integer key = new Integer(identifier.trim());

            if (calls.containsKey(key)) {
                int elapsedTime = callRecord.getElapsedTime();
                CallRecord cr = (CallRecord) calls.get(key);
                callRecord.setCallCount(cr.getCallCount() + 1);
                callRecord.setElapsedTime(cr.getElapsedTime()
                                + elapsedTime);
            }
            calls.put(key, (CallRecord) callRecord);
        } // end for
        outputCallRecords(calls);
    }

    public static void outputCallRecords(HashMap calls) {
        Set entries = calls.entrySet();
        Iterator it = entries.iterator();
        ArrayList allCalls = new ArrayList();
        int index = -1;
        while (it.hasNext()) {
            Map.Entry entry = (Map.Entry) it.next();
            CallRecord callRecord = (CallRecord) entry.getValue();
            index++;
            String text = callRecord.getElapsedTime() + " "
                            + callRecord.getThreadId() + " "
                            + callRecord.getCallCount() + " "
                            + callRecord.getText();

            allCalls.add(index, text);

            // utility.display(text);
        }
        String[] callArray = new String[allCalls.size()];
        allCalls.toArray(callArray);
        Arrays.sort(callArray);
        allCalls.clear();
        for (int i = callArray.length - 1; i >= 0; i--) {
            // utility.display(callArray [i]);
            callCostWriter.println(callArray[i]);
        }
    }

}

