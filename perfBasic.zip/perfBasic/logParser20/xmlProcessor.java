package logParser20;

import org.w3c.dom.Element;
import org.w3c.dom.Document;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import org.xml.sax.SAXException;
import org.w3c.dom.Attr;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import java.util.HashMap;
import java.io.File;
import java.io.*;
import org.apache.xml.serialize.*;

public class xmlProcessor {
    Document document;

    public xmlProcessor(String XMLFile) {
        File file = new File(XMLFile);
        DocumentBuilderFactory factory = DocumentBuilderFactory
                        .newInstance();
        try {
            DocumentBuilder builder = factory.newDocumentBuilder();
            try {
                document = builder.parse(file);
                System.out.println("final xml doc created from "
                                + XMLFile);
            } catch (IOException sxe) {
                System.out.println(sxe.toString());
            } catch (SAXException sxe) {
                System.out.println(sxe.toString());
            }
        } catch (ParserConfigurationException pce) {
            System.out.println(pce.toString());
        }
    }

    public void writeDocumentToFile(Document dom) {
        // following code serializes
        // dom to xml file
        // Document dom = getDocument();
        OutputFormat of = new OutputFormat("XML", "UTF-8", true);
        XMLSerializer serializer = new XMLSerializer();
        serializer.setOutputFormat(of);
        try {
            serializer.setOutputByteStream(new FileOutputStream(
                            params.callTreeXMLFileFinal));
        } catch (FileNotFoundException e) {
            System.out.println(e.getMessage().toString());
        }
        try {
            serializer.serialize(dom);
        } catch (IOException ioe) {
            System.out.println(ioe.getMessage().toString());
        }

    }

    public Document getDocument() {
        return document;
    }

    public Document updateAllDestNodes(HashMap relations) {
        Document doc = getDocument();
        NodeList nodeList = doc.getElementsByTagName("treelink");
        long[] relationInfo = new long[3];
        int total = nodeList.getLength();
        System.out.println("updateAllDestNodes: ");
        for (int i = 0; i < total; i++) {
            Element e = (Element) nodeList.item(i);
            String fromId = e.getAttribute("from");
            String toId = e.getAttribute("to");
            String id = fromId + "->" + toId;
            relationInfo = getRelationInfo(id, relations);
            // int callCount = (int)relationInfo [0];
            int elapsedTime = (int) relationInfo[1];
            long lastCallEndTime = relationInfo[2];
            Element E = (Element) findNodeById(toId);
            if (E == null)
                continue;
            String timeSum = E.getAttribute("timeSum");
            String CallCountSum = E.getAttribute("callCountSum");
            int callCountSum = (int) relationInfo[0]
                            + Integer.parseInt(CallCountSum);
            int TimeSum = elapsedTime;
            // System.out.println("update " + id + " with elapsedTime
            // = " + elapsedTime);
            try {
                TimeSum = elapsedTime + Integer.parseInt(timeSum);
                E.setAttribute("timeSum", Integer.toString(TimeSum));
                E.setAttribute("callCountSum", Integer
                                .toString(callCountSum));
                E.setAttribute("callEndTime", Long
                                .toString(lastCallEndTime));
            } catch (java.lang.NumberFormatException f) {
                System.out.println("Error with id " + id);
            }

        }
        return doc;
    }

    public void printNode(Node node) {

        NamedNodeMap attributeNodes = node.getAttributes();
        System.out.print("<" + node.getNodeName());
        for (int i = 0; i < attributeNodes.getLength(); i++) {
            Attr attribute = (Attr) attributeNodes.item(i);
            System.out.print(" " + attribute.getNodeName() + "="
                            + "\"" + attribute.getNodeValue() + "\"");
        }
        System.out.println(">");
    }

    public void processNode(Node currentNode) {
        if (currentNode.getNodeType() == Node.DOCUMENT_NODE) {
            NodeList children = currentNode.getChildNodes();
            processChildNodes(children);
        } else if (currentNode.getNodeType() == Node.ELEMENT_NODE) {
            processChildNodes(currentNode.getChildNodes());
        } else {
            processChildNodes(currentNode.getChildNodes());
        }

    }

    public String getIdAttributeValue(Node currentNode) {
        NamedNodeMap attributeNodes = currentNode.getAttributes();
        String idValue = "";
        for (int i = 0; i < attributeNodes.getLength(); i++) {
            Attr attribute = (Attr) attributeNodes.item(i);
            if (attribute.getNodeName().equals("id")) {
                /*
                 * System.out.println("ATTR " +
                 * attribute.getNodeName() + " " +
                 * attribute.getNodeValue());
                 */
                idValue = attribute.getNodeValue();
            }
        }
        return idValue;
    }

    public String getNodeAttributeValue(Node currentNode,
                    String attributeName) {
        NamedNodeMap attributeNodes = currentNode.getAttributes();
        String value = "";
        if (attributeNodes == null)
            return value;
        for (int i = 0; i < attributeNodes.getLength(); i++) {
            Attr attribute = (Attr) attributeNodes.item(i);
            if (attribute.getNodeName().equals(attributeName)) {
                value = attribute.getNodeValue();
            }
        }
        return value;
    }

    public String getElementAttributeValue(Element e,
                    String attributeName) {
        String value = e.getAttribute(attributeName);
        return value;
    }

    public int getRefCountOfTargetNode(String idValueToMatch) {
        // for a given node, find how many treelinks has toId value
        // equal to its idValue
        Document doc = getDocument();
        NodeList nodeList = doc.getElementsByTagName("treelink");
        int count = 0;
        for (int i = 0; i < nodeList.getLength(); i++) {
            Element e = (Element) nodeList.item(i);
            String toId = e.getAttribute("to");
            if (toId.equals(idValueToMatch)) {

                count++;
            }
        }
        System.out.println("count = " + count + " for "
                        + idValueToMatch);
        return count;
    }

    public void processChildNodes(NodeList children) {
        if (children.getLength() != 0) {
            for (int i = 0; i < children.getLength(); i++) {
                processNode((Node) children.item(i));
            }
        }
    }

    public Document treeFilter(Document doc) {
        NodeList treeNodeList = doc.getElementsByTagName("treenode");
        trimCallTreeByNode(treeNodeList);
        return doc;
    }

    public boolean trimCallTreeByNode(NodeList treeNodeList) {

        int timeSum = 0;
        int nodeCount = treeNodeList.getLength();
        boolean removed = true;
        utility.display("trimCallTreeByNode: " + nodeCount
                        + " treenodes");
        Node[] node = new Node[nodeCount];
        for (int i = 0; i < nodeCount; i++) {
            node[i] = treeNodeList.item(i);
        }
        for (int m = 0; m < nodeCount; m++) {
            // Node treeNode = treeNodeList.item(m);
            Node treeNode = node[m];
            if (treeNode == null)
                continue;
            String name = getNodeAttributeValue(treeNode, "id");
            if (name.equals("root"))
                continue;
            timeSum = Integer
                            .parseInt(getNodeAttributeValue(treeNode,
                                                            "timeSum"));

            /*
             * utility.display("m = " + m + " " + " name = " + name + "
             * timeSum = " + timeSum);
             */
            if (timeSum < params.elapsedTimeThresholdInMS) {
                removed = removeNode(treeNode);
            }
        }
        return removed;
    }

    public boolean removeNode(Node n) {
        boolean removed = false;
        Node node = n.getParentNode();
        if (node != null) {
            node.removeChild(n);
            removed = true;
        }
        return removed;
    }

    public Document updateAllLinks(HashMap relations) {
        String tagName = "treelink";
        Document doc = getDocument();
        NodeList nodeList = doc.getElementsByTagName(tagName);

        Element[] allElements = new Element[nodeList.getLength()];
        for (int i = 0; i < nodeList.getLength(); i++) {
            allElements[i] = (Element) nodeList.item(i);
        }
        long[] relationInfo = new long[3];
        String id = "";
        int callCount = -1;
        int elapsedTime = -1;
        int total = nodeList.getLength();
        long callEndTime = -1;
        utility.display("UpdateAllLinks: total # of links: " + total);
        for (int i = 0; i < total; i++) {
            Element e = allElements[i];

            if (e == null)
                continue;

            String fromId = e.getAttribute("from");
            String toId = e.getAttribute("to");
            id = fromId + "->" + toId;

            relationInfo = getRelationInfo(id, relations);
            callCount = (int) relationInfo[0];
            elapsedTime = (int) relationInfo[1];
            callEndTime = relationInfo[2];
            e.setAttribute("callCount", Integer.toString(callCount));
            e.setAttribute("elapsedTime", Integer
                            .toString(elapsedTime));
            e.setAttribute("callEndTime", Long.toString(callEndTime));
            NodeList children = e.getElementsByTagName("property");
            Element property = (Element) children.item(0);
            property.setTextContent("(" + elapsedTime + " / "
                            + callCount + ")");
        }
        return doc;
    }

    public Node findNodeById(String idValueToMatch) {
        Node node = null;
        Document doc = getDocument();
        String tagName = "treenode";
        NodeList nodeList = doc.getElementsByTagName(tagName);

        String idValue = "";
        for (int i = 0; i < nodeList.getLength(); i++) {
            Element e = (Element) nodeList.item(i);
            idValue = e.getAttribute("id");
            if (idValue.equals(idValueToMatch)) {
                node = (Node) e;
                continue;
            }
        }
        return node;
    }

    public long[] getRelationInfo(String relationId, HashMap relations) {
        long[] relationInfo = new long[3];
        relationInfo[0] = -1;
        relationInfo[1] = -1;
        relationInfo[2] = -1;
        // System.out.println ("getRelationInfo with " + relationId);
        if (relations.containsKey(relationId)) {
            long[] temp = (long[]) relations.get(relationId);
            relationInfo[0] = temp[0];
            relationInfo[1] = temp[1];
            relationInfo[2] = temp[2];

        }
        return relationInfo;
    }
}
