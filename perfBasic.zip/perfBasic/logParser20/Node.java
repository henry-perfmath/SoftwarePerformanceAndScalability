package logParser20;

public class Node {
    String id;

    String namespace;

    String name;

    long callStartTime;

    long callEndTime;

    int elapsedTimeSum;

    int callCountSum;

    String type;

    String text;

    public Node(String namespace, String name, long callStartTime,
                    long callEndTime, String type, int elapsedTimeSum,
                    int callCountSum, String text) {
        this.namespace = namespace;
        this.name = name;
        this.callStartTime = callStartTime;
        this.callEndTime = callEndTime;
        this.type = type;
        this.elapsedTimeSum = elapsedTimeSum;
        this.callCountSum = callCountSum;
        this.id = namespace + ":" + name;
        this.text = text;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public String getNamespace() {
        return namespace;
    }

    public void setNamespace(String namespace) {
        this.namespace = namespace;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getCallCountSum() {
        return callCountSum;
    }

    public void setCallCount(int count) {
        this.callCountSum = count;
    }

    public int getElapsedTimeSum() {
        return elapsedTimeSum;
    }

    public void setElapsedTimeSum(int elapsedTimeSum) {
        this.elapsedTimeSum = elapsedTimeSum;
    }

    public long getCallStartTime() {
        return callStartTime;
    }

    public void setCallStartTime(long time) {
        this.callStartTime = time;
    }

    public long getCallEndTime() {
        return callEndTime;
    }

    public void setCallEndTime(long time) {
        this.callEndTime = time;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
}
