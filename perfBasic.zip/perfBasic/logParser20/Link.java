package logParser20;

import logParser20.Node;

public class Link {
    Node sourceNode;

    Node destNode;

    String name;

    int callCount;

    long elapsedTime;

    String isLink;

    String color;

    String namespace;

    String id;

    public Link(String namespace, String name, Node srcNode,
                    Node destNode, int callCount, long elapsedTime,
                    String isLink, String color) {
        this.namespace = namespace;
        this.sourceNode = srcNode;
        this.destNode = destNode;
        this.name = name;
        this.callCount = callCount;
        this.elapsedTime = elapsedTime;
        this.isLink = isLink;
        this.color = color;
        this.id = namespace + ":" + name;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getNamespace() {
        return namespace;
    }

    public void setNamespace(String namespace) {
        this.namespace = namespace;
        ;
    }

    public String getName() {
        return name;
    }

    public String getIsLink() {
        return isLink;
    }

    public void setIsLink(String isLink) {
        this.isLink = isLink;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getCallCount() {
        return callCount;
    }

    public void setCallCount(int callCount) {
        this.callCount = callCount;
    }

    public Node getSourceNode() {
        return sourceNode;
    }

    public void setSourceNode(Node src) {
        this.sourceNode = src;
    }

    public Node getDestNode() {
        return destNode;
    }

    public void setDestNode(Node dest) {
        this.destNode = dest;
    }

    public long getElapsedime() {
        return elapsedTime;
    }

    public void setElapsedTime(long time) {
        elapsedTime = time;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }
}
