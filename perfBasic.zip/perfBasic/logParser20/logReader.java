package logParser20;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.StringTokenizer;

public class logReader {
    public static HashMap threadID = new HashMap();

    public static long[] threadTimeMin = new long[params.maxThreads];

    public static long[] threadTimeMax = new long[params.maxThreads];

    public static long[] threadTimeDelta = new long[params.maxThreads];

    public static long allThreadTimeMin = 0;

    public static long allThreadTimeMax = 0;

    public static long allThreadTimeTotal = 0;

    public static String[] threadFileNames = new String[params.maxThreads];

    public static String fileNamePrefix = "";

    public static String traceLogOnDate = "";

    public static long traceLogOnDateInMS = 0;

    public static int threadIndexMax = 0;

    public static void getThreadInfo(String threadInfoFileName) {
        BufferedReader reader = null;
        String line = "";
        try {
            reader = new BufferedReader(new FileReader(
                            params.threadFileDir + "/"
                                            + threadInfoFileName));
            line = reader.readLine();
            fileNamePrefix = line.substring(line.indexOf("=") + 1);
            line = reader.readLine();
            threadIndexMax = Integer.parseInt(line.substring(line
                            .indexOf("=") + 1));
            line = reader.readLine();
            allThreadTimeMin = Long.parseLong(line.substring(line
                            .indexOf("=") + 1));
            line = reader.readLine();
            allThreadTimeMax = Long.parseLong(line.substring(line
                            .indexOf("=") + 1));
            line = reader.readLine();
            allThreadTimeTotal = Long.parseLong(line.substring(line
                            .indexOf("=") + 1));
            for (int i = 0; i < threadIndexMax; i++) {
                line = reader.readLine();
                StringTokenizer st = new StringTokenizer(line, " ");
                String threadId = st.nextToken();
                threadTimeMin[i] = Long.parseLong(st.nextToken());
                threadTimeMax[i] = Long.parseLong(st.nextToken());
                threadTimeDelta[i] = Long.parseLong(st.nextToken());
                threadFileNames[i] = params.threadFileDir + "/"
                                + fileNamePrefix + "_T" + i + ".txt";
            }
        } catch (IOException ioe) {
            utility.display(threadInfoFileName + " not found");
        }

    }

    public static void sortLogByThread() {
        long startTime = System.currentTimeMillis();
        BufferedReader reader = null;
        PrintWriter threadInfo = null;

        String fileNamePrefix = params.fileNamePrefix;
        try {
            reader = new BufferedReader(new FileReader(
                            params.apfInputFileName));
            String threadInfoFileName = params.threadFileDir + "/"
                            + fileNamePrefix + "_threadInfo.txt";
            threadInfo = utility.createWriter(threadInfoFileName);
            utility.display("threadInfoFileName="
                            + threadInfoFileName);
        } catch (IOException ioe) {
            utility.display(params.logFileName + " not found");
        }

        String line = null;
        String[] columns = new String[8];
        PrintWriter[] threadWriter = new PrintWriter[params.maxThreads];

        int lineNum = 0;
        int[] lineInThreadFile = new int[params.maxThreads];

        for (int i = 0; i < params.maxThreads; i++) {
            lineInThreadFile[i] = 0;
        }

        for (int i = 0; i < params.maxThreads; i++) {
            threadTimeMax[i] = 0;
            threadTimeMin[i] = System.currentTimeMillis();
        }

        do {
            try {
                line = reader.readLine();
                lineNum++;
                if (line != null && line.length()>0) {
                    StringTokenizer tLeft = new StringTokenizer(line,
                                    ",");
                    //System.out.println(line);
                    // extract first 6 columns
                    for (int i = 0; i < 8; i++) {
                        columns[i] = tLeft.nextToken();
                    }
                    String firstEntry = columns[0];
                    String ThreadID = columns[1];
                    long callTime = Long.parseLong(columns[2]);
                    String ServerID = columns[3];
                    String ThreadGroupID = columns[4];
                    String ClientID = columns[5];
                    String User = columns[6];
                    String text = columns[7];
                    // We now have firstEntry ThreadID RPCID Queue
                    // ClientRPC User timeStamp text
                    if (!threadID.containsKey(new String(ThreadID))) {
                        threadID.put(new String(ThreadID),
                                     new Integer(threadIndexMax));
                        threadFileNames[threadIndexMax] = params.threadFileDir
                                        + "/"
                                        + fileNamePrefix
                                        + "_T"
                                        + threadIndexMax + ".txt";
                        threadWriter[threadIndexMax] = utility
                                        .createWriter(threadFileNames[threadIndexMax]);
                        threadIndexMax++;
                    }
                    int thread = ((Integer) (threadID.get(new String(
                                    ThreadID)))).intValue();

                    lineInThreadFile[thread]++;
                    // utility.display("Convert " + timeStamp + " to "
                    // + callTime);
                    // find min max thread times
                    if (callTime < threadTimeMin[thread]) {
                        threadTimeMin[thread] = callTime;
                    }
                    if (callTime > threadTimeMax[thread]) {
                        threadTimeMax[thread] = callTime;
                    }
                    // 11/2/2006 changed callTime relative to
                    // traceLogOnDateInMS
                    threadWriter[thread].println(callTime + "|^"
                                    + text + "|~" + firstEntry + "$$"
                                    + ThreadID);
                }

            } catch (IOException io) {
                utility.display("Error reading or writing with "
                                + params.logFileName);
            }
        } while (line != null);

        try {
            reader.close();
        } catch (IOException ie) {
        }

        utility.display("# of threads = " + (threadIndexMax));
        utility.display("Total number of lines = " + lineNum);
        utility.println(params.sumWriter, "# of threads = "
                        + (threadIndexMax), true);
        utility.println(params.sumWriter, "Total number of lines = "
                        + lineNum, false);

        allThreadTimeMin = threadTimeMax[0];
        allThreadTimeMax = threadTimeMin[0];
        threadTimeDelta[0] = threadTimeMax[0] - threadTimeMin[0];
        int linesSumInAllThreads = 0;
        for (int i = 0; i < threadIndexMax; i++) {
            // close threadWriter here
            threadWriter[i].close();
            linesSumInAllThreads = linesSumInAllThreads
                            + lineInThreadFile[i];
            if (threadTimeMin[i] < allThreadTimeMin)
                allThreadTimeMin = threadTimeMin[i];
            if (threadTimeMax[i] > allThreadTimeMax)
                allThreadTimeMax = threadTimeMax[i];
            threadTimeDelta[i] = threadTimeMax[i] - threadTimeMin[i];
        }
        utility
                        .display("Total number of lines in all thread files  = "
                                        + linesSumInAllThreads);
        allThreadTimeTotal = allThreadTimeMax - allThreadTimeMin;
        utility.display("allThreadTimeMin = " + allThreadTimeMin
                        + " allThreadTimeMax = " + allThreadTimeMax
                        + " allThreadTimeTotal = "
                        + allThreadTimeTotal + " ms");
        utility.println(params.sumWriter,
                        "Total number of lines in all thread files  = "
                                        + linesSumInAllThreads,
                        false);
        utility.println(params.sumWriter, "allThreadTimeMin = "
                        + allThreadTimeMin + " allThreadTimeMax = "
                        + allThreadTimeMax + " allThreadTimeTotal = "
                        + allThreadTimeTotal + " ms", false);

        threadInfo.println("fileNamePrefix=" + fileNamePrefix);
        threadInfo.println("threadIndexMax=" + threadIndexMax);
        threadInfo.println("allThreadTimeMin=" + allThreadTimeMin);
        threadInfo.println("allThreadTimeMax=" + allThreadTimeMax);
        threadInfo
                        .println("allThreadTimeTotal="
                                        + allThreadTimeTotal);
        for (int i = 0; i < threadIndexMax; i++) {
            threadInfo.println(i + " " + threadTimeMin[i] + " "
                            + threadTimeMax[i] + " "
                            + threadTimeDelta[i]);
        }
        threadInfo.close();
        utility.display("reading log file: "
                        + (System.currentTimeMillis() - startTime)
                        + " ms");

    }

}
