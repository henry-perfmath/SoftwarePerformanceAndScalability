package logParser20;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.util.*;

public class params {

    public static String description = "test";

    public static int maxThreads = 50;
    public static int threadSample = 1;
    public static String inputFileDir = "";

    public static String outputFileDir = "";

    public static String threadFileDir = "";

    public static String logFileName = "";

    public static String apfInputFileName = "";

    public static String fileNamePrefix = "";

    public static boolean logFileIsSortedByThread = false;

    public static String threadInfoFileName = "";

    public static String callTreeXMLFile0 = "";

    public static String callTreeXMLFileFinal = "";

    public static String callTreeDotFile = "";

    public static boolean graphByThread = false;

    public static int threadPercentTimeFilter = 0;

    public static boolean traceTreeWalkThrough = false;

    public static boolean profilingOn = false;

    public static boolean subGraph = false;

    public static boolean dotLinkLabelHorizontal = false;

    public static boolean deleteThreadFiles = true;

    public static boolean relativeToLogOnTime = true;

    public static int elapsedTimeThresholdInMS = 1;

    public static int elapsedTimePercentRed = 10;

    public static String[] ignoreLinesIdentifiers;

    public static String[] callEndIdentifiers;

    public static String[] selfNodeIdentifiers;
   
    public static PrintWriter sumWriter;

    public static boolean xmlProcessing;

    public static void init() {
        InputStream parserPropsFile;
        InputStream logPropsFile;
        Properties props = new Properties();
        Properties logProps = new Properties();
        try {
            parserPropsFile = new FileInputStream(System
                            .getProperty("user.dir")
                + "/parser.properties");
            props.load(parserPropsFile);
            maxThreads = Integer.parseInt(props.getProperty(
                "maxThreads", "50"));
            inputFileDir = System.getProperty("user.dir") + "/"
                + props.getProperty("inputFileDir");
            outputFileDir = System.getProperty("user.dir") + "/"
                + props.getProperty("outputFileDir");
            threadFileDir = System.getProperty("user.dir") + "/"
                + props.getProperty("threadFileDir");
            logFileName = props.getProperty("logFileName");
            logFileIsSortedByThread = Boolean.parseBoolean(props
                            .getProperty("logFileIsSortedByThread"));
            threadInfoFileName = props
                            .getProperty("threadInfoFileName");
            callTreeDotFile = props.getProperty("callTreeDotFile");
            callTreeXMLFile0 = props.getProperty("callTreeXMLFile0");
            callTreeXMLFileFinal = props
                            .getProperty("callTreeXMLFileFinal");
            description = props.getProperty("description", "test");
            graphByThread = Boolean.parseBoolean(props
                            .getProperty("graphByThread"));
            relativeToLogOnTime = Boolean.parseBoolean(props
                            .getProperty("relativeToLogOnTime"));
            dotLinkLabelHorizontal = Boolean.parseBoolean(props
                            .getProperty("dotLinkLabelHorizontal"));
            subGraph = Boolean.parseBoolean(props
                            .getProperty("subGraph"));
            threadPercentTimeFilter = Integer.parseInt(props
                            .getProperty("threadPercentTimeFilter"));
            elapsedTimeThresholdInMS = Integer.parseInt(props
                            .getProperty("elapsedTimeThresholdInMS"));
            threadSample = Integer.parseInt(props
                            .getProperty("threadSample"));
            elapsedTimePercentRed = Integer.parseInt(props
                            .getProperty("elapsedTimePercentRed",
                                "10"));
            traceTreeWalkThrough = Boolean.parseBoolean(props
                            .getProperty("traceTreeWalkThrough"));
            deleteThreadFiles = Boolean.parseBoolean(props
                            .getProperty("deleteThreadFiles"));
            profilingOn = Boolean.parseBoolean(props
                            .getProperty("profilingOn"));
            xmlProcessing = Boolean.parseBoolean(props
                            .getProperty("xmlProcessing"));

            logPropsFile = new FileInputStream(System
                            .getProperty("user.dir")
                + "/log.properties");
            logProps.load(logPropsFile);

            String ignoreLinesStrings = logProps
                            .getProperty("ignoreLines");
            String callEndStrings = logProps.getProperty("callEnd");
            String selfNodeStrings = logProps.getProperty("selfNode");
           
            ignoreLinesIdentifiers = getIdentifies(ignoreLinesStrings);
            callEndIdentifiers = getIdentifies(callEndStrings);
            selfNodeIdentifiers = getIdentifies(selfNodeStrings);

            String logParsingDate = (new Date().toString()).replace(
                ' ', '_');
            logParsingDate = "_" + logParsingDate.replace(':', '_');
            String logFileNamePrefix = logFileName.substring(0,
                params.logFileName.indexOf("."));
            apfInputFileName = inputFileDir + "/" + logFileNamePrefix
                + ".apf";
            fileNamePrefix = logFileNamePrefix
                + logParsingDate.substring(4);
        } catch (IOException io) {
            utility.display("Failed to read "
                + "properties file ... " + io.getMessage());
            System.exit(-1);
        }

        String sumFileName = outputFileDir + "/" + fileNamePrefix
            + "_summary.txt";
        sumWriter = utility.createWriter(sumFileName);
        sumWriter.println("All initial parameters:");
        writeParams("*********************************");
        writeParams("description: " + description);
        writeParams("threadSample: " + threadSample);
        writeParams("inputFileDir: " + inputFileDir);
        writeParams("logFileName: " + logFileName);
        writeParams("callTreeDotFile: " + callTreeDotFile);
        writeParams("callTreeXMLFile1: " + callTreeXMLFile0);
        writeParams("callTreeXMLFile2: " + callTreeXMLFileFinal);
        writeParams("graphByThread: " + graphByThread);
        writeParams("relativeToLogOnTime: " + relativeToLogOnTime);
        writeParams("dotLinkLabelHorizontal: "
            + dotLinkLabelHorizontal);
        writeParams("subGraph: " + subGraph);
        writeParams("threadPercentTimeFilter: "
            + threadPercentTimeFilter);
        writeParams("elapsedTimeThreshold: "
            + elapsedTimeThresholdInMS);
        writeParams("elapsedTimePercentRed: " + elapsedTimePercentRed);
        writeParams("traceTreeWalkThrough: " + traceTreeWalkThrough);
        writeParams("deleteThreadFiles: " + deleteThreadFiles);
        /*
        writeParams("ignoreIdentifiers: " + ignoreLinesIdentifiers);
        writeParams("callEndIdentifiers: " + callEndIdentifiers);
        writeParams("selfNodeIdentifiers: " + selfNodeIdentifiers);
       */
        writeParams("xmlProcessing: " + xmlProcessing);
        writeParams("*********************************");
    }

    public static void writeParams(String s) {
        sumWriter.println(s);
    }

    public static String[] getIdentifies(String s) {
        String stringContent = s.substring(1, s.length() - 1);
        StringTokenizer st = new StringTokenizer(stringContent, ",");
        int tokenCount = st.countTokens();
        String[] identifiers = new String[tokenCount];
        for (int i = 0; i < tokenCount; i++) {
            identifiers[i] = st.nextToken().trim();
            identifiers[i] = identifiers[i].substring(1,
                identifiers[i].length() - 1);
        }
        return identifiers;
    }

    public static String getInputFilename() {
        return inputFileDir + "/" + logFileName;
    }
}
